﻿///////////////////////////////////////////////////////////////
////-------------------------------------------------------////
////---- FUNÇÃO QUE DETERMINA QUAL O NÍVEL DA PERGUNTA ----////
////-------------------------------------------------------////
///////////////////////////////////////////////////////////////

function questionCurrent(questionNumber, language) {
    if(language == "pt") {
        if (questionNumber == 1) {
            return quizQuestions1;
        }
        else if (questionNumber == 2) {
            return quizQuestions2;
        }
        else if (questionNumber == 3) {
            return quizQuestions3;
        }
        else if (questionNumber == 4) {
            return quizQuestions4;
        }
        else if (questionNumber == 5) {
            return quizQuestions5;
        }
        else if (questionNumber == 6) {
            return quizQuestions6;
        }
        else if (questionNumber == 7) {
            return quizQuestions7;
        }
        else if (questionNumber == 8) {
            return quizQuestions8;
        }
        else if (questionNumber == 9) {
            return quizQuestions9;
        }
        else if (questionNumber == 10) {
            return quizQuestions10;
        }
        else if (questionNumber == 11) {
            return quizQuestions11;
        }
        else if (questionNumber == 12) {
            return quizQuestions12;
        }
        else if (questionNumber == 13) {
            return quizQuestions13;
        }
        else if (questionNumber == 14) {
            return quizQuestions14;
        }
        else if (questionNumber == 15) {
            return quizQuestions15;
        }
        else if (questionNumber == 16) {
            return quizQuestions16;
        }
        else if (questionNumber == 17) {
            return quizQuestions17;
        }
        else if (questionNumber == 18) {
            return quizQuestions18;
        }
        else if (questionNumber == 19) {
            return quizQuestions19;
        }
        else if (questionNumber == 20) {
            return quizQuestions20;
        }
    } else {
        if (questionNumber == 1) {
            return quizQuestions1en;
        }
        else if (questionNumber == 2) {
            return quizQuestions2en;
        }
        else if (questionNumber == 3) {
            return quizQuestions3en;
        }
        else if (questionNumber == 4) {
            return quizQuestions4en;
        }
        else if (questionNumber == 5) {
            return quizQuestions5en;
        }
        else if (questionNumber == 6) {
            return quizQuestions6en;
        }
        else if (questionNumber == 7) {
            return quizQuestions7en;
        }
        else if (questionNumber == 8) {
            return quizQuestions8en;
        }
        else if (questionNumber == 9) {
            return quizQuestions9en;
        }
        else if (questionNumber == 10) {
            return quizQuestions10en;
        }
        else if (questionNumber == 11) {
            return quizQuestions11en;
        }
        else if (questionNumber == 12) {
            return quizQuestions12en;
        }
        else if (questionNumber == 13) {
            return quizQuestions13en;
        }
        else if (questionNumber == 14) {
            return quizQuestions14en;
        }
        else if (questionNumber == 15) {
            return quizQuestions15en;
        }
        else if (questionNumber == 16) {
            return quizQuestions16en;
        }
        else if (questionNumber == 17) {
            return quizQuestions17en;
        }
        else if (questionNumber == 18) {
            return quizQuestions18en;
        }
        else if (questionNumber == 19) {
            return quizQuestions19en;
        }
        else if (questionNumber == 20) {
            return quizQuestions20en;
        }
    }
        
}
