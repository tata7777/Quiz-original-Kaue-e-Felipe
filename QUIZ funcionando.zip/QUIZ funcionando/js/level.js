﻿const achiev = [
    {
        name: "Entusiasta em Soldagem"          // 0
    },
    {
        name: "Soldador de Final de Semana"     // 1
    },
    {
        name: "Vendedor em Soldagem"            // 2
    },
    {
        name: "Soldador Amador"                 // 3
    },
    {
        name: "Aluno de Graduação"              // 4
    },
    {
        name: "Aluno de IC em Soldagem"         // 5
    },
    {
        name: "Soldador Profissional"           // 6
    },
    {
        name: "Soldador Internacional"          // 7
    },
    {
        name: "Prático Int. de Soldagem"        // 8
    },
    {
        name: "Inspetor IWI-B"                  // 9
    },
    {
        name: "Técnico Int. de Soldagem"        // 10
    },
    {
        name: "Mestrando em Soldagem"           // 11
    },
    {
        name: "Doutorando em Soldagem"          // 12
    },
    {
        name: "Inspetor IWI-S"                  // 13
    },
    {
        name: "Mestre em Soldagem"              // 14
    },
    {
        name: "Inspetor IWI-C"                  // 15
    },
    {
        name: "Doutor em Soldagem"              // 16
    },
    {
        name: "Tecnólogo Int. em Soldagem"      // 17
    },
    {
        name: "Engenheiro Int. de Soldagem"     // 18
    },
    {
        name: "Engenheiro Sênior de Soldagem"   // 19
    },
    {
        name: "Professor Titular de Soldagem"   // 20
    },
    {
        name: ""                                // 21
    },
    {
        name: ""                                // 22
    }
];